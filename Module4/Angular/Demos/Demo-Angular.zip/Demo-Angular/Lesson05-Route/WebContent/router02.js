/**
 * 
 */
var sampleApp = angular.module('sampleApp',['ngRoute']);
 
sampleApp.config(function($routeProvider){
	$routeProvider
		/* #/department/java or net or testing or system */
		.when('/department/:depId',                            
		{
			templateUrl: "member.html",
			controller: 'DepartmentController'
		
		});
	//$locationProvider.html5Mode(false);
});
 
sampleApp.controller('DepartmentController', function($scope, $routeParams) {
 $scope.dep_id=$routeParams.depId;
 if($scope.dep_id=='java'){
	 //alert('hiii');
	 $scope.members=[
	                 {'id':1001,'name':'Rahul'},
	                 {'id':1002,'name':'Anju'},
	                 {'id':1003,'name':'Vinod'}
	                 ];
 }
 if($scope.dep_id=='testing'){
	 $scope.members=[
	                 {'id':1004,'name':'Dayanand'},
	                 {'id':1005,'name':'Nilima'},
	                 {'id':1006,'name':'Radhika'}
	                 ];
 }
 if($scope.dep_id=='net'){
	 $scope.members=[
	                 {'id':1007,'name':'Nachiket'},
	                 {'id':1008,'name':'Shital'},
	                 {'id':1009,'name':'Vaishali'}
	                 ];
 }
 if($scope.dep_id=='system'){
	 $scope.members=[
	                 {'id':1010,'name':'Vishal'},
	                 {'id':1011,'name':'Rahul'},
	                 {'id':1012,'name':'Shradha'}
	                 ];
 }
 
 
	
});