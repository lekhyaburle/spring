/**
 * DI 
 */

var sample =angular.module('diexample',[]);
sample.controller('DiController',['$scope', function(myscope) {
	//attaching SIMPLE
	myscope.message='Hello Angular ......';
}]);



